SELECT * FROM sys.dm_os_schedulers;
GO
