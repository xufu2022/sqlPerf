USE [AdventureWorks2012]
GO
SET NOCOUNT ON;
EXECUTE [Person].[GetNextDuplicateCustomerSet] 1;
